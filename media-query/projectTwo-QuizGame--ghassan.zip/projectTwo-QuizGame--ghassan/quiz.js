const btn = document.querySelector('.quiz-btn');
const quizRules = document.querySelector('.quiz-rules');
const quiz = document.querySelector('.quiz');

btn.addEventListener('click', ()=>{
  location.href="quiz.html";
});
